package Recursos_ejercicio1;

import java.net.SocketAddress;
import java.util.Random;
import java.util.Scanner;

public class Cliente {
	final String FICHEROPROPIEDADES = "files/config.properties";
	String host;
	int port;
	Random generador;
	int id;
	SocketAddress address;
	public static final int CANTIDAD_NUMEROS_PRIMOS = 20;
	public static final int MAX_VALOR_NUMERO_PRIMO = 500_000;
	
	public Cliente(int id){
		//TODO
	}
	
	public void iniciar(){
		//TODO
	}

	public static void main (String args[]){
		Scanner teclado = new Scanner (System.in);
		System.out.print("Id del cliente: ");
		int id = teclado.nextInt();
		Cliente ejercicio = new Cliente(id);
		ejercicio.iniciar();
		teclado.close();
	}
}
