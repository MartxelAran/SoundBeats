package Recursos_ejercicio1;

public class Servidor {
	private static final int BUFFER_SIZE = 1024;
	final int PUERTO = 5000;
	
	//TODO
	
	public Servidor() {
		//TODO
	}
	
	public void start() {
		//TODO
	}
	
	//TODO
	
	private boolean esPrimo(int valor){
		for (int i = 2; i<(Math.sqrt(valor)+1);i++){
			if (valor%i ==0){
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		Servidor servidor = new Servidor();
		servidor.start();
	}

}
