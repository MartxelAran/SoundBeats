package Recursos_ejercicio2;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.ConnectionFactory;
import java.util.Random;
import java.util.Scanner;

public class Corredor {
    private String id_corredor;
    private double incremento; //Avance del corredor en metros (ritmo constante del corredor).
    ConnectionFactory factory;
    Random generador;
    Channel channel;
    volatile boolean fin = false;
	
    public Corredor(String id_corredor) {
    	this.id_corredor = id_corredor;
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		generador = new Random();
		incremento = (generador.nextDouble() * 10) + 1; //Los metros que avanzará cada segundo el corredor.
		incremento = Math.round(incremento * 100) / 100.0; //Para quedarnos solo con dos decimales.
    }
    
	public void publicar() {
		//TODO
    }
	
	//TODO
	
    public static void main(String[] args) {
    	Scanner teclado= new Scanner(System.in);
		System.out.print("Numero ID corredor: ");
		String id_corredor = teclado.nextLine();
		Corredor publisher = new Corredor(id_corredor);
		publisher.publicar();
		teclado.close();
	}
}