package Recursos_ejercicio2;

import com.rabbitmq.client.ConnectionFactory;
import java.util.Scanner;

public class VisualizadorCarrera {

    ConnectionFactory factory;
    private static final double DISTANCIA_CARRERA = 20.0; //Distancia total en metros de la carrera.
    //TODO
    
    public VisualizadorCarrera() {
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		//TODO
	}
    
	public void suscribe() {
		//TODO
    }
	
	//TODO
	
	public synchronized void stop() {
		this.notify();
	}
 
    public static void main(String[] args) {
    	VisualizadorCarrera suscriber = new VisualizadorCarrera();
		Scanner teclado = new Scanner(System.in);
		
		System.out.println(" [*] VisualizadorCarrera esperando mensajes. Pulsa return para finalizar.");
		
		Thread hiloEspera = new Thread(()-> {
			teclado.nextLine();
			suscriber.stop();
		});
		
		hiloEspera.start();
		suscriber.suscribe();
		teclado.close();
	}
}

