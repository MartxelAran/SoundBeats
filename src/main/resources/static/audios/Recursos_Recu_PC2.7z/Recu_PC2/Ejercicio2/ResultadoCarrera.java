package Recursos_ejercicio2;


import com.rabbitmq.client.ConnectionFactory;
import java.util.Scanner;


public class ResultadoCarrera {
	
    private static final double DISTANCIA_CARRERA = 20.0; //Distancia total en metros de la carrera.
    ConnectionFactory factory;
    //TODO
	
    public ResultadoCarrera() {
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		//TODO
	}
    
	public void suscribe() {
		//TODO
    }
	
	//TODO
	
	public synchronized void stop() {
		this.notify();
	}
 
    public static void main(String[] args) {
    	ResultadoCarrera suscriber = new ResultadoCarrera();
		Scanner teclado = new Scanner(System.in);
		
		System.out.println(" [*] ResultadoCarrera esperando mensajes. Pulsa return para finalizar.");
		
		Thread hiloEspera = new Thread(()-> {
			teclado.nextLine();
			suscriber.stop();
		});
		
		hiloEspera.start();
		suscriber.suscribe();
		teclado.close();
	}
}